package com.cg.hcs.bean;
import java.time.format.DateTimeFormatter;

public class Appointment {
	User user;
	Test test;
	DateTimeFormatter date;
	boolean approved;
	
	
}
