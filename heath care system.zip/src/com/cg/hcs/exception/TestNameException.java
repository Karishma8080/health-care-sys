package com.cg.hcs.exception;

public class TestNameException extends Exception{
		public TestNameException() {
			System.out.println("Test name must be in characters..!");
		}
}
